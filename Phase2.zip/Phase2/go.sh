./go ./testCase/test1.go
./sym ./testCase/test1.go

./go ./testCase/test2.go
./go ./testCase/test3.go
./go ./testCase/test4.go
./go ./testCase/test5.go
./go ./testCase/test6.go
./sym ./testCase/test1.go



