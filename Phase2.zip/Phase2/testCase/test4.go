func main ()
{
	int a := 0; ///vbshjbvhjsbvjh////  //**//*4654	
	fmt.print("%d men",a := 55);//zz
	switch (a)
	{
		/* */
		case 1 : ;
		default: ;
	}
}
	/*  // // // // u man*/
