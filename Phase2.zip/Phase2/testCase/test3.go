package main 

func main ()
{
	int a := 0; ///vbshjbvhjsbvjh////  //**//*4654	
	fmt.print("%d anna",a := 55);//
	switch1; (a)
	{
		/* */
		case 1 ;
		default: ;
	}
}
	/*  // // // // u test*/
