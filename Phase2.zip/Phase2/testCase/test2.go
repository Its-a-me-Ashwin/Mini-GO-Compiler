package main 

func main ()
{
	int a := 0; ///vbshjbvhjsbvjh////  //**//*4654	
	fmt.print("%d hi",a := 55)//;
	switch (a)
	{
		/* */
		case 1 : break;
		default: ;
	}
}
	/*  // // // // u hjkl;ay*/
