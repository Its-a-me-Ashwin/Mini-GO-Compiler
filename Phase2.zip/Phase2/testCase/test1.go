package main 

func main ()
{
	int a := 0, b,c; ///vbshjbvhjsbvjh////  //**//*4654	
	fmt.print("%d hello",a := 55);//
	switch (a)
	{
		/* */
		case 1 : ;
		default: ;
	}
}
	/*  // // // // u shaaeeeer*/
