package main 

func main ()
{
	int a := 0; ///vbshjbvhjsbvjh////  //**//*4654	
	fmt.print("%d bous",a := 55);//
	switch (a)
	{
		/* */
		case 1 :z ;
		default: ;
	}

	/*  // // // // u hello every one*/
