func main() {
	int a := 10;
	int b := 480;
	int d := a + b + 420;
	fmt.Printf("Nice");
}

