func main() {
	int a := 10;
	int b := 480;
	int c := 100 / 2;
	c := 55 * 2;
	int d := a + b + 420;
	fmt.Printf("Optimizer");
}

