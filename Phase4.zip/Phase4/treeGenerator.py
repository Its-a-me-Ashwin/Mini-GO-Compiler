from anytree import AnyNode, RenderTree
from anytree.exporter import DotExporter
import os
import json


try:
    f = open("out.txt", "r")
    mm = dict()
    l = f.readline()
    l = l[0:len(l)-1]
    tt = AnyNode(name=l, val=l[:l.rfind("(")])

    nodes = list()
    edges = list()
    mm[l] = tt
    l = f.readline()
    while(len(l)>0):
        l = l[0:len(l)-1]
        a = l.split("`")
        ss = a[1][:a[1].rfind("(")]
        #print("Parent",a[0],"Child",a[1])
        nodes.append(a[0])
        nodes.append(a[1])
        edges.append((a[0],a[1]))
        ty = AnyNode(name=a[1],parent= mm[a[0]], val=ss)
        if(a[1] not in mm.keys()):
            mm[a[1]] = ty
        l = f.readline()

    nodes = list(set(nodes))
    f.close()
    ids = dict()
    i = 1
    for j in nodes:
        ids[j] = i
        i = i + 1

    
    f = open('test.html',"r")
    hTMLcode = f.read()
    f.close()

    nodes = list(map(lambda x: {"id" : ids[x], "label" : x},nodes))
    edges = list(map(lambda x: {"from" : ids[x[0]], "to" : ids[x[1]]},edges))  
    
    
    a = hTMLcode.find("nodes = ;")+len("nodes =")
    hTMLcode = hTMLcode[:a] + json.dumps(nodes) + hTMLcode[a:] 
    b = hTMLcode.find("edges = ;")+len("edges =")
    hTMLcode = hTMLcode[:b] + json.dumps(edges) + hTMLcode[b:] 

    f = open("OutputTree/tree.html", "w")
    f.write(hTMLcode)
    f.close()
except Exception as e:
    print("Wrong tree format",e)
