bison -d -v -b y parserpp.y 
flex lexer.l
g++ y.tab.c lex.yy.c 
rm lex.yy.c
rm y.tab.h
rm y.tab.c
rm y.output
./a.out "Test/test2.go" > out.txt
python3	treeGenerator.py
#eog "OutputTree/tree.png" &
