bison -d -v -b y parserpp.y 
flex lexer.l
g++ y.tab.c lex.yy.c 
rm lex.yy.c
rm y.tab.h
rm y.tab.c
rm y.output
./a.out "Test/test3.go" > out.txt
python3 lol.py
#eog "OutputTree/tree.png" &
