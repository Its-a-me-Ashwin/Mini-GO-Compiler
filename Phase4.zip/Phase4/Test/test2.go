func main() {
	int a := 5+6+78;
	int b,c,d,e;
	e := a+b*c;
	c := a/b/c;
	b++;
	int i := 69;
	for (i < 420) 
	{
		i++;
	}
	fmt.Printf("Hot");
}

