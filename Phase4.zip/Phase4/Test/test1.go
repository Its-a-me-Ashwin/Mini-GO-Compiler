func main() {
	int a := 5+6+78;
	int b,c,d,e;
	e := a+b*c;
	c := a/b/c;
	b++;
	fmt.Printf("Hello");
}

