from math import ceil
f = open("icfg.txt",'r')    #optimised intermediate code take
data = f.readlines()
data = data[1:]
f.close()
imc = list()
for line in data:
    some_var = line.split('|')
    imc.append({"op":some_var[0],"ar1":some_var[1],"ar2":some_var[2],"res":some_var[3]})
#print(imc)

f = open("st.txt",'r')
data = f.readlines()
data = data[1:]
f.close()
st = list()

used_var = list()
to_be_used_var = list()

for line in data:
    some_var = line.split(':')
    st.append({"name":some_var[0],"type":some_var[1],"dtype":some_var[2],"val":some_var[3].strip('\n')})

registers = [0] * 16 # assuming 256 registers are available

def getRegister(lineNo):
    found = registers.index(0)
    if found >= 0:
        return found
    else:
        for i in range(lineNo):
            imc[i]


#print(registers)
vars = list()
for line in st:
    if line["type"] == "Identifier":
        vars.append(line["name"]) 

#print(";16 Registers Available (R15 is Addresss Allocattor)\n\n\n\n")


def checkIfRegisterUSedAfter(var,table):
    return 


assembly = open("asstmp.txt","w")

available_reg = [0 for i in range(15)]

used_reg = [0 for i in range(15)]

# some_dict = [{i:0} for i in range(15)]

some_dict = dict()

for i in range(0,14):#15 is reserved
    some_dict[i] = -1
arr1 = '0'
arr2 = '0'
res = '0'
some_list = list()
extraVars = list()

leastUSedReg = None
leastUSedRegTemp = None

registerToTem = dict()

print(".TEXT")
for i, line in enumerate(imc):
    # print(str(i) + "loop--------------------------------------------------" + str(line["res"]) + " " + str(line["ar2"]) + " " + str(line["ar1"]))
    res_av = False
    ar1_av = False 
    ar2_av = False
    flag_1 = True
    # print(some_dict)
    for i_ in some_dict:
        if(some_dict[i_] == line["res"][1:] or '#' in line["res"]):
            flag_1 = False
    if(flag_1 and line["res"].isnumeric() == False):
        for i_ in some_dict:
            if(some_dict[i_] == -1):
                res_av = True
                res = "R" + str(i_)
                some_dict[i_] = line["res"][1:]
                break
    
    flag_1 = True



    for i_ in some_dict:
        if(some_dict[i_] == line["ar1"][1:] or '#' in line["ar1"]):
            if(line["ar1"].isnumeric() == False):
                arr1 = "R" + str(i_)
            flag_1 = False
    if(flag_1 and line["ar1"].isnumeric() == False):
        for i_ in some_dict:
            if(some_dict[i_] == -1):
                ar1_av = True
                arr1 = "R"+str(i_)
                # print("arr1 changed")
                some_dict[i_] = line["ar1"][1:]
                break
    
    flag_1 = True
    for i_ in some_dict:
        if(some_dict[i_] == line["ar2"][1:] or '#' in line["ar2"]):
            if(line["ar1"].isnumeric() == False):
                arr2 = "R" + str(i_)
            flag_1 = False
    if(flag_1 and line["ar2"].isnumeric() == False and line["ar2"] != ''):
        for i_ in some_dict:
            if(some_dict[i_] == -1):
                arr2 = "R"+str(i_)
                # print("arr 2 changed")
                ar2_av = True
                some_dict[i_] = line["ar2"][1:]
                break
    time_to_delete = dict()
    for some_k in some_dict.values():
        if(some_k != -1):
            time_to_delete[some_k] = True
    # print(time_to_delete)
    for j in range(i+1, len(imc)):

        if((imc[j]["res"].isnumeric() == False) and imc[j]["res"] != ''):
            re_1 = imc[j]["res"][1:]
            if(re_1 in time_to_delete.keys()):
                time_to_delete[re_1] = False
                # print("Can delete " + str(re_1))
        # else:
        #     print(imc[j]["res"], imc[j]["res"].isnumeric(), '#' in imc[j]["res"], )


        if(imc[j]["ar1"].isnumeric() == False and imc[j]["ar1"] != ''):
            # print("entered")
            ar_1 = imc[j]["ar1"][1:]
            if(ar_1 in time_to_delete.keys()):
                time_to_delete[ar_1] = False
                # print("Can delete " + str(ar_1))
        # else:
        #     print(imc[j]["ar1"], imc[j]["ar1"].isnumeric(), '#' in imc[j]["ar1"], )
        if(imc[j]["ar2"].isnumeric() == False and imc[j]["ar2"] != ''):
            ar_2 = imc[j]["ar2"][1:]
            if(ar_2 in time_to_delete.keys()):
                time_to_delete[ar_2] = False
                # print("Can delete " + str(ar_2))
    # print(time_to_delete)

    key_list = list(some_dict.keys()) 
    val_list = list(some_dict.values())
    for i in time_to_delete.keys():
        if(time_to_delete[i] == True):
            some_dict[key_list[val_list.index(i)]] = -1
            # print('--------------------------------------------')
    if(ar1_av and ar2_av and res_av):
        pass
    else:
        pass

    leastUsed = [0]*14
    
    # all registers are used
    if -1 not in some_dict.values():
        # find the register used after the most ammount of time
        for j in range(i+1, len(imc)):
            key_list = list(some_dict.keys()) 
            val_list = list(some_dict.values())
            try:
                q = key_list[val_list.index(imc[j]["res"][1:])] # the register beingused 
                leastUsed[q] = 1
                if 0 not in leastUsed:
                    leastUSedReg = q
                    break
                q = key_list[val_list.index(imc[j]["ar1"][1:])]
                leastUsed[q] = 1
                if 0 not in leastUsed:
                    leastUSedReg = q
                    break
                q = key_list[val_list.index(imc[j]["ar2"][1:])]
                leastUsed[q] = 1
                if 0 not in leastUsed:
                    leastUSedReg = q
                    break
            except:
                pass
        if leastUSedReg is not None:
            extraName = "CONTACTSWITCH#"+str(len(extraVars))
            extraVars.append(extraName)
            print("LDR R15","=",extraName)
            print("STR R15","[","R",leastUSedReg,"]")
            registerToTem[leastUSedReg] = extraName
    
    if str(leastUSedRegTemp) in line["ar1"]:
        print("LDR",leastUSedReg,"",registerToTem[leastUSedReg])

    
    if str(leastUSedRegTemp) in line["ar2"]:
        print("LDR",leastUSedReg,"",registerToTem[leastUSedReg])

    
    if str(leastUSedRegTemp) in line["res"]:
        print("LDR",leastUSedReg,"",registerToTem[leastUSedReg])

    op = None
    if line["op"] == "=": op = "MV"
    if line["op"] == "+": op = "ADD"
    if line["op"] == "*": op = "MUL"
    if line["op"] == "/": op = "DIV"
    if line["op"] == "-": op = "SUB"
    if line["op"] == "==": op = "CMP" ## addADD more
    if line["op"] == "Lable": op = "LABLE"
    if line["op"] == "goto": op = "GOTO"
    if line["op"] == "ifFalse": op = "ifFalse"
    if op == "ADD":
        # print("ADD",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
        print("ADD",res,"#"+line["ar1"] if line["ar1"].isnumeric() else arr1,"#"+line["ar2"] if line["ar2"].isnumeric() else arr2)
    elif op == "SUB":
        # print("SUB",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
        print("SUB",res,"#"+line["ar1"] if line["ar1"].isnumeric() else arr1,"#"+line["ar2"] if line["ar2"].isnumeric() else arr2)
    elif op == "MUL":
        # print("MUL",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
        print("MUL",res,"#"+line["ar1"] if line["ar1"].isnumeric() else arr1,"#"+line["ar2"] if line["ar2"].isnumeric() else arr2)
    elif op == "DIV":
        # print("DIV",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
        print("DIV",res,"#"+line["ar1"] if line["ar1"].isnumeric() else arr1,"#"+line["ar2"] if line["ar2"].isnumeric() else arr2)
    elif op == "CMP":
        # print("CMP(",line["op"],")",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
        print("CMP(",line["op"],")",res,"#"+line["ar1"] if line["ar1"].isnumeric() else arr1,"#"+line["ar2"] if line["ar2"].isnumeric() else arr2)
    elif op == "GOTO":
        print("GOTO",line["res"][1:])
    elif op == "LABLE":
        print("LABLE "+line["res"][1:]+":")
    elif op == "MV":
        # do load and store
        if line["ar1"].find("#") >= 0:
            # load
            # print("LDR",line["res"],"=",line["ar1"])
            print("LDR",res,"=",line["ar1"])
        elif line["res"].find("#") >= 0:
            # store
            # loads the address and pushes data back
            # print("LDR R15","=",line["res"])
            print("LDR R15","=",line["res"])
            print("STR R15","[",arr1,"]")
        else:
            # print("MV",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"])
            print("MV",res,"#"+line["ar1"] if line["ar1"].isnumeric() else arr1)
    elif op == "ifFalse":
        #print("ifFlase",line["ar1"],":","GOTO",line["res"][1:])
        print("ifFlase",arr1,":","GOTO",line["res"][1:])
    elif line["op"] == "Param":
        # print("PARAM",line["ar1"])
        print("PARAM",arr1)
    elif line["op"] == "call":
        # print("CALL",line["ar1"],line["ar2"],"; Loaded from {FMT}")
        print("CALL",arr1,arr2,"; Loaded from {FMT}")
    else:
        print(line)
print("SWI 0x11")
print("\n\n.DATA")

total = 0
for var in st:
    size = None
    dtype = None
    if var["type"] == "Identifier":
        dtype = "WORD"
        size = 32
        if var["dtype"] == "int":
            size = 32
            dtype = "WORD"
        if var["type"] == "float":
            size = 64
            dtype = "DWORD"
        total += size
        print(var["name"],":.",dtype,";","Scope:",var["name"].split("#")[1], "Size:",size)
for vars in extraVars:
    print(vars,":.","LONGint",";","Scope:","None", "Size:",32)
    total += 32
print(".END; Total Memory Used:", ceil(total/8),"bytes")


assembly.close()
