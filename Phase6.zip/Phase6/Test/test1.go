// goooooooooooooooo
func main() {
	int a := 5 + 5;
	int b := 8 * 8 * 12;
	int c := 69/69;
	int d := 0 * c;
	fmt.Printf("Hello Bois");
}




/*


for line in imc:
    if "#" in line["ar1"] and line["op"] == "=":
        # id foun
        var = line["ar1"]
        tmp = line["res"]
        print("Nibba",var,getVal(st,var))
        for j in range(imc.index(line)+1,len(imc)):
            if imc[j]["res"] == var: break
            '''
            newLine = dict()
            newLine["ar1"] = imc[j]["ar1"]
            newLine["ar2"] = imc[j]["ar2"]
            newLine["op"] = imc[j]["op"]
            newLine["res"] = imc[j]["res"]
            '''
            if imc[j]["ar1"] == tmp:
                setVal(st,tmp,getVal(st,var) if getVal(st,var) != None else None)
                #newLine["ar1"] = var
            if imc[j]["ar2"] == tmp:
                setVal(st,tmp,getVal(st,var) if getVal(st,var) != None else None)
                #newLine["ar2"] = var
            #imc[j] = newLine



print()
print()




print("Oper\t|Arg1\t|Arg2\t|Result|")
for i in imc:
    print (i["op"],"\t|",i["ar1"],"\t|",i["ar2"],"\t|",i["res"])

print()
print()





print("name\t|Value\t|")
for i in st:
    print (i["name"],"\t|",i["val"],"\t|")



print()
print()




            


*/