
func main() {
	int a := 5+6+78;
	int b,c,d,e;
	switch (a)
	{
		case 1: b++; break;
		case 2:	c := a + 69; break;
		case 3:	d := 55;
		case 4:	e := 69;
		default : fmt.Printf("mario");
	}
	fmt.Printf("Hot");
}
/*
func main() {
	int a := 4, b := 5;
	int c:= a+b;
	
	fmt.Printf("Done");
}
*/