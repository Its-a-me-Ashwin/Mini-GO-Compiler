func main() {
	int a := 5+6+78;
	int i;
	for (i < 420) 
	{
		i++;
	}
	fmt.Printf("High Five");
}

