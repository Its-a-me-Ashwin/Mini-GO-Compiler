f = open("icfg.txt",'r')
data = f.readlines()
data = data[1:]
f.close()
imc = list()

for line in data:
    gay = line.split('|')
    imc.append({"op":gay[0],"ar1":gay[1],"ar2":gay[2],"res":gay[3]})
#print(imc)

f = open("st.txt",'r')
data = f.readlines()
data = data[1:]
f.close()
st = list()

for line in data:
    gay = line.split(':')
    st.append({"name":gay[0],"type":gay[1],"dtype":gay[2],"val":gay[3].strip('\n')})

registers = [0] * 16 # assuming 256 registers are available

def getRegister(lineNo):
    found = registers.index(0)
    if found >= 0:
        return found
    else:
        for i in range(lineNo):
            imc[i]


#print(registers)
vars = list()
for line in st:
    if line["type"] == "Identifier":
        vars.append(line["name"]) 

#print(";16 Registers Available (R15 is Addresss Allocattor)\n\n\n\n")


def checkIfRegisterUSedAfter(var,table):
    return 


assembly = open("asstmp.txt","w")

print(".TEXT")
for line in imc:
    op = None
    if line["op"] == "=": op = "MV"
    if line["op"] == "+": op = "ADD"
    if line["op"] == "*": op = "MUL"
    if line["op"] == "/": op = "DIV"
    if line["op"] == "-": op = "SUB"
    if line["op"] == "==": op = "CMP" ## addADD more
    if line["op"] == "Lable": op = "LABLE"
    if line["op"] == "goto": op = "GOTO"
    if line["op"] == "ifFalse": op = "ifFalse"

    if op == "ADD":
        print("ADD",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
    elif op == "SUB":
        print("SUB",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
    elif op == "MUL":
        print("MUL",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
    elif op == "DIV":
        print("DIV",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
    elif op == "CMP":
        print("CMP(",line["op"],")",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"],"#"+line["ar2"] if line["ar2"].isnumeric() else line["ar2"])
    elif op == "GOTO":
        print("GOTO",line["res"][1:])
    elif op == "LABLE":
        print("LABLE "+line["res"][1:]+":")
    elif op == "MV":
        # do load and store
        if line["ar1"].find("#") >= 0:
            # load
            print("LDR",line["res"],"=",line["ar1"])
        elif line["res"].find("#") >= 0:
            # store
            # loads the address and pushes data back
            print("LDR t15","=",line["res"])
            print("STR t15","[",line["ar1"],"]")
        else:
            print("MV",line["res"],"#"+line["ar1"] if line["ar1"].isnumeric() else line["ar1"])
    elif op == "ifFalse":
        print("ifFlase",line["ar1"],":","GOTO",line["res"][1:])
    elif line["op"] == "Param":
        print("PARAM",line["ar1"])
    elif line["op"] == "call":
        print("CALL",line["ar1"],line["ar2"],"; Loaded from {FMT}")
    else:
        print(line)
print("SWI 0x11")
print("\n\n.DATA")




for var in st:
    size = None
    dtype = None
    if var["type"] == "Identifier":
        dtype = "WORD"
        size = 32
        if var["dtype"] == "int":
            size = 32
            dtype = "WORD"
        if var["type"] == "float":
            size = 64
            dtype = "DWORD"
        print(var["name"],":.",dtype,";","Scope:",var["name"].split("#")[1], "Size:",size)
print(".END; Total Memory Used:", len(var)*32,"bits")


assembly.close()
#print(imc)
#print(st)
