bison -d -v -b y parserpp.y 
flex lexer.l
g++ y.tab.c lex.yy.c 
rm lex.yy.c
rm y.tab.h
rm y.tab.c
rm y.output
./a.out "Test/test1.go" > out.txt
