/* Here we do sufff i like bois */
func main () 
{
	int a := 0 + 69 * 5;
	switch 	((a))
	{
		case 1: a := 55;
		case 2: a := 69;
	}
	for (a < 50)
	{
		a += 5;
	}
}


