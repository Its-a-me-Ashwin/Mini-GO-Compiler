from anytree import AnyNode, RenderTree
from anytree.exporter import DotExporter

try:    
	parent_child = dict()
	f = open("out.txt", "r").readlines()
	root = f[0][0:len(f[0])-1]
	tt = AnyNode(name=root, val=root[:root.rfind("(")])
	parent_child[root] = tt
	if f[len(f) - 1] == 'scess\n':
		print("Building tree")
		for node in range(1,len(f)-1):
			t = f[node][0:len(f[node])-1]
			a = t.split('`')
			ss = a[1][:a[1].rfind("(")]
			ty = AnyNode(name=a[1],parent= parent_child[a[0]], val=ss)
			if(a[1] not in parent_child.keys()):
				parent_child[a[1]] = ty
	DotExporter(tt).to_picture("OutputTree/tits.png")	
	print(tt)
except e as Exception:
	print("Failed in AST department cause: ",e)
'''
    mm = dict()


    l = f.readline()

    l = l[0:len(l)-1]
    tt = AnyNode(name=l, val=l[:l.rfind("(")])

    mm[l] = tt
    l = f.readline()
    while(len(l)>0):
        l = l[0:len(l)-1]
        a = l.split("`")
        ss = a[1][:a[1].rfind("(")]
        ty = AnyNode(name=a[1],parent= mm[a[0]], val=ss)
        if(a[1] not in mm.keys()):
            mm[a[1]] = ty
        l = f.readline()



    DotExporter(tt).to_picture("OutputTree/tree.png")
    # DotExporter(tt).to_dotfile("OutputTree/trees.dot")

except:
    print("Wrong tree format")'''
