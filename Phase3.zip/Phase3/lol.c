#include <stdio.h>
void main(){
    int a;
    float b = 3.2;
    a = b;
    printf("lol\n");
}