
/*

author ganzaki

*/


int main()
{
  int a=0;
  {
    int b;
    b = (1+2)*3 + 4*5;
  }
  while(1){
    {
        int a;
    }
  }
  while(a<9){
    switch(a){
        case 1:
            a = 7;
            break;
        default:
            a++;
    }
  }
    /*
    while(1){
        while(1){
            switch (a)
            {
            case '1':
                while(1){
                    int a = 1;
                }
                break;
            
            default:
                break;
            }
        }
    }
    while (i=3)
    {
        int a = 1; // llol
        // lol
        a++;
        ++a;
        // l ol
        
        switch('c'){
            case 'd': b = 1;
            break;
            case 2 : {
                int bb = 0;

                bb+=1;
                b*=2;
            }
            default:{
                break;
            }
        }
        int z = 1;
        z = 10;
    }
    printf("lol %d", 4);
    return 0;*/
}

/*
author ganzaki

*/
/*
author ganzaki

*/