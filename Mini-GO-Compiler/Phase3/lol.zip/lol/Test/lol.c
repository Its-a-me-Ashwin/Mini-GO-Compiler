int main()
{
  int a=1;
  double b = 2.3;
  a = 1*2+3;
  a = b;
}